
var tab = new Array () ;//tableau contenant les adresses des images retournees
var tab1 = new Array () ; //tableau contenant les identifiants des images retournees

a =0 ; //compteur permettant de savoir le nombre de clics
j= 1 ; //compteur nous permettant de savoir le nombre de faces retournées pour faire la comparaison des faces (max = 2)

n = 0 ; // 2 fois le nombre de paires trouvees . On compare cette valeur aux nombres de cartes ( la taille du tableau maVar passée avec pyhton)
l =0 ; //le nombre de clics de l'utilisateur

function ajouter(k,i){
  tab[a] = k ; //on insere ladresse dans le tableau
  tab1[a] = i; //on insere lidentifiant de la case
  l = l+1 ;
  
   // on insere le click dans la base de données
    $.ajax({
        url :'/inserer_coup?id_case='+i+'&ordre='+l+'&idpartie='+idpartie, //cette variable contient l'id de la case clique et l'odre du clique
        type : 'GET',
        success: function() {
 		     //alert('ok');
 		},
 		error: function() {
 		  alert('err');
 		}
     });
  
  
  
if( l < nbClick ) {  //on compare si le nombre de clics l au nombre de clics max par niveau
 if (n < maVar-1) { //on compare le nombre de paires trouvées au nombre de paires de la parties pour tester sil a gagné ou pas
  if (tab.length > 0) {
      if ((j==2 && tab[a] == tab[a-1])) {
       document.getElementById(tab1[a]).src = tab[a];
       document.getElementById(tab1[a-1]).src = tab[a]; // on change montre la face si le joueur trouve en cliquant deux fois de suite 
       j=0;
       n = n+2 ;// on remet j a 0 pour quil ne compare pas le suivant avec celui quil a deja trouve et on incremente le nombre de paires trouvees
      }
      else if(j==2 && tab[a] != tab[a-1]){
       document.getElementById(tab1[a-1]).src = "static/Images/lune.jpg";
       //s'il clic 2 fois de suite sans trouver on renverse la face (montre le dos)
          j =1 ;

      }
      else if (j!=2 && tab[a] == tab[a-1]) {
          document.getElementById(tab1[a]).src = tab[a];
       document.getElementById(tab1[a-1]).src = tab[a];
       j=0 ;
        n= n+2 ;
     }
   j= j+1 ;
   }

  a = a+1 ; //on incremente a
 }
 if(n>maVar -2){ //on incremente n par 2 donc si n > nbre de paires -2 ca veut dire quil a gagné

        //on envoies les données a la route pour l'inserer dans la BD avec etat = 1=gagné
        
        $.ajax({
            url :'/fin_partie?etat='+1+'&ordre='+l+'&idpartie='+idpartie, //cette variable contient l'etat de la partie et l'ordre du dernier clique
            type : 'GET',
            success: function() {
                //alert('ok');
            },
            error: function() {
            alert('err');
            }
        });
        
        alert('vous avez gagné en '+l +' coups sur '+nbClick +', vous pouvez passer au niveau suivant') ; //on lui dit qu'il  a gagné
        if(idNiveau<3){// le boutton niveau suivant ne saffiche quand le idNiveau<3
            document.getElementById("niv-suiv").innerHTML = "<button type=\"button\" calss='next-level'>niveau suivant</button>";
            $(".next-level").click(function() {
                window.location.replace('/jouer?id='+(idNiveau+1));
            
                });

           
        }
        
    }
}



if (l > nbClick ) { // si le nbre de clics du joueur > nbre de clics max autorisé il perd
  
 
  //on envoies les données a insertdata.php pour l'inserer dans la BD
  $.ajax({
        url :'/fin_partie?etat='+0+'&ordre='+l+'&idpartie='+id_parie, //ette variable contient l'etat de la partie et l'ordre du dernier clique
        type : 'GET',
        success: function() {
 		     //alert('ok');
 		},
 		error: function() {
 		  alert('err');
        }
     });
        alert( 'Vous avez perdu avec '+l +' coups sur '+nbClick +', veuillez recommencer');
        // on affiche le bouttoncpour recommencer
        document.getElementById("niv-suiv").innerHTML = "<button type=\"button\" calss='next-level'>recommencer</button>";
            $(".next-level").click(function() {
                window.location.replace('/jouer?id='+idNiveau);
            
                });
   
   
  
}
  
}


function ChangeImage(url,i) {
        var time = Date.now(); //on stock le temps dans une variable
        //alert(maVar);
        var a = url ; 
        var element = document.getElementById(i);
        element.classList.add('flip');
        
        console.log(document.getElementById(i).src);
         // si la face de limage est cachée on retourne la face et on apelle la fonction ajouter pour comparer
        if (document.getElementById(i).src == "http://127.0.0.1:5000/static/Images/lune.jpg"){
            
            document.getElementById(i).src = url; 
  

            ajouter (a , i); //apelle de la fonction ajouter pour faire le traitement et les comparaisons.
          
        console.log('je suis clické');
        console.log(url,i);
        }    
 
}
 
